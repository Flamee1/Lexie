class ConfidenceError(Exception):
    pass


class InternalError(Exception):
    pass


class InvalidTokenError(Exception):
    pass


class MissingTokenError(Exception):
    pass
