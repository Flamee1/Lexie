from Stephanie.boot import Boot


b = Boot()
b.initiate()
